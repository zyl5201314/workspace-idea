package com.ytc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootDubboConsumerAnntionApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootDubboConsumerAnntionApplication.class, args);
	}

}
