/**
 * Copyright (C), 2015-2020, XXX有限公司
 * FileName: UserService
 * Author:   zyl
 * Date:     2020/8/17 10:24
 * History:
 */
package com.ytc.service;

/**
 * 〈一句话功能简述〉<br> 
 * 〈〉
 *
 * @author zyl
 * @create 2020/8/17
 * @since 1.0.0
 */
public interface UserService {

    public void hello(String name,String age);

    public String sayHello(String name,String hobby);
}
